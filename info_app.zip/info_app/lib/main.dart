import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';


void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Container(
          constraints: BoxConstraints.expand(),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.bottomLeft,
              end: Alignment.topRight,
              colors: [
                Color(0xfff12711),
                Color(0xfff5af19),
              ],
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 200.0),
                child: CircleAvatar(
                  radius: 70.0,
                  backgroundImage: AssetImage('images/dp.jpeg'),
                ),
              ),
              Text(
                'Tanmay Mohapatra',
                style: TextStyle(
                  fontFamily: 'Quicksand',
                  color: Colors.white,
                  fontSize: 40.0,
                  letterSpacing: 3.0,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 40.0),
                child: Text(
                  'Flutter & UI/UX Developer',
                  style: TextStyle(
                    fontFamily: 'Quicksand',
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  IconButton(
                    icon: Icon(FontAwesomeIcons.instagram,color: Colors.white,),
                    onPressed: () {},
                    iconSize:60.0,
                  ),

                  IconButton(
                    icon: Icon(FontAwesomeIcons.linkedin,color: Colors.white,),
                    onPressed: () {},
                    iconSize:60.0,
                  ),
                ],
              ),
              SizedBox(
                height: 30.0,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  IconButton(
                    icon: Icon(FontAwesomeIcons.globe,color: Colors.white,),
                    onPressed: () {},
                    iconSize:60.0,
                  ),
                  IconButton(
                    icon: Icon(FontAwesomeIcons.facebookSquare,color: Colors.white,),
                    onPressed: () {},
                    iconSize:60.0,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
